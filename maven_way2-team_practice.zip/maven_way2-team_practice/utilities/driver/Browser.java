package driver;

public class Browser {

	public static void maximizeBrowser()
	{
		Invoke.webDriver.manage().window().maximize();
		
	}// End of maximizeBrowser
	
		
}//End of BrowserCapabilities
